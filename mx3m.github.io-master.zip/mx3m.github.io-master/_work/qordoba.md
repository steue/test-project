---
title:            "Qordoba"
date:             2013-12-12 14:00:00
year:             2013
class:            qordoba
color:            "#EBEDFB"
cover:            "/img/work/qordoba/qordoba-cover.svg"
hyperlink:        https://dribbble.com/mx3m/projects/178815-Qordoba
type:             "Web / UI Design"
description:      "Order and checkout flows for a Dubai startup"
runin:            "Dubai's startup Qordoba asked me to redesign their localization order/checkout form. Our goal was to make it easier for Qordoba's customers to order in custom localization work while keeping an eye on how much it will cost them. We added a few mechanics to lower time and budget according to the customer's needs."
layout:           post
---

<img class="post-content-screen desktop" src="{{ site.baseurl }}/img/work/qordoba/qordoba-checkout.png" />
